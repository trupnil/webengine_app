<?php
	define("DB_SERVER","localhost");
	define("DB_USER","root");
	define("DB_NAME","bscan");
	define("DB_PASS","");
	define("MAXtoSEND",2);