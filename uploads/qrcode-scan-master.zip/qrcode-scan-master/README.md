## QRCode-scan

QRCode-scan is an online employee 
attendance and time tracking web application.

* A QR-code is generated for each employee.
* Each employee gets its own QR-code printed on a badge.
* Each time the employee gets in or out the QR-code gets scanned and the time is recorded in the database.
* The website gives detailed informations about every employee and also weekly and monthly charts.   